# Досье CRA

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

- [Досье CRA](CRA/PRODUCT.md)
- [Декларация соответствия ЕС — черновик](CRA/EU-DECLARATION-DRAFT.md)
- [Поддержка и окончание срока службы](CRA/SUPPORT.md)
- [Безопасность](CRA/VULNERABILITIES.md)
- [Реагирование на инциденты](CRA/INCIDENT-RESPONSE.md)
- [Инструкции пользователю](CRA/USER-INSTRUCTIONS.md)
- [Результаты испытаний](CRA/TEST-EVIDENCE.md)

- [SBOM](bom.cdx.json)
- [Матрица требований](CRA/REQUIREMENTS.csv)
- [Устройства и активы](ASSETS.csv)
- [Журнал действий](MAINTENANCE.csv)
