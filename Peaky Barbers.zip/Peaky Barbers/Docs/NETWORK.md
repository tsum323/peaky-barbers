# Архитектура

Опишите архитектуру, интерфейсы, зависимости и схемы.

```mermaid
flowchart LR
  A[Client] -->|TLS| B[Service]
  B --> C[(Database)]
```
