# Инструкции пользователю

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "foreseeable_security_risks" : [

  ],
  "full_or_simplified_declaration_url" : "",
  "integration_requirements" : "",
  "intended_purpose" : "",
  "manufacturer_and_security_contact" : "",
  "operating_environment_and_interfaces" : "",
  "product_identifier" : "",
  "reference" : "CRA Annex II",
  "sbom_location_if_public" : "",
  "secure_decommissioning_data_erasure" : "",
  "secure_installation_configuration_operation" : "",
  "security_updates_and_opt_out" : "",
  "support_end_date" : ""
}
```
