# Результаты испытаний

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "approval_date" : "",
  "automated_and_manual_test_reports" : [

  ],
  "product_version_and_source_revision" : "",
  "reference" : "CRA Annex VII(6)",
  "reproducible_build_and_artifact_hashes" : [

  ],
  "requirements_to_test_mapping" : [

  ],
  "reviewer" : "",
  "security_test_findings" : [

  ],
  "test_environment" : "",
  "unresolved_risks_and_acceptance" : [

  ],
  "vulnerability_handling_tests" : [

  ]
}
```
