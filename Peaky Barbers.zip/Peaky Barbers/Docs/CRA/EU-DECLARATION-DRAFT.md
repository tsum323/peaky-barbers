# Декларация соответствия ЕС — черновик

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "additional_information" : "",
  "approved_evidence_links" : [

  ],
  "assessment_procedure_and_certificate_id" : "",
  "conformity_statement_and_applicable_union_legislation" : "",
  "harmonised_standards_common_specifications_certifications" : [

  ],
  "manufacturer_or_authorised_representative_name_address" : "",
  "notified_body_name_number_if_applicable" : "",
  "object_identification_traceability_photo" : "",
  "place_date" : "",
  "product_name_type_unique_id" : "",
  "published_declaration_url" : "",
  "reference" : "CRA Article 28; Annex V",
  "required_market_languages" : [

  ],
  "signatory_name_function" : "",
  "signature" : "",
  "signed_on_behalf_of" : "",
  "sole_responsibility_statement" : "",
  "status" : "DRAFT_UNSIGNED"
}
```
