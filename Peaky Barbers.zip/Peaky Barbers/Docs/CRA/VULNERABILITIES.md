# Безопасность

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "coordinated_disclosure_workflow" : "",
  "dependency_inventory" : "../bom.cdx.json",
  "disclosure_policy_url" : "",
  "public_advisories_and_patch_verification" : [

  ],
  "reference" : "CRA Annex I Part II",
  "regular_security_reviews" : [

  ],
  "remediation_targets" : "",
  "reporting_contact" : "",
  "secure_update_distribution_evidence" : [

  ],
  "supplier_escalation" : "",
  "triage_owner" : "",
  "vulnerability_register" : "VULNERABILITIES.csv"
}
```
