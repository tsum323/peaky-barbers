# Реагирование на инциденты

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "actively_exploited_vulnerability_or_severe_incident" : "",
  "affected_products_versions" : [

  ],
  "authority_csirt_enisa_contacts" : [

  ],
  "awareness_time_utc" : "",
  "containment_and_remediation" : [

  ],
  "early_warning_due_24h" : "",
  "follow_up_reports" : [

  ],
  "impact_and_indicators" : [

  ],
  "incident_final_report_due_one_month_after_notification" : "",
  "notification_due_72h" : "",
  "owner_and_deputy" : "",
  "post_incident_review" : "",
  "reference" : "CRA Article 14",
  "submitted_report_receipts" : [

  ],
  "user_notifications" : [

  ],
  "vulnerability_final_report_due_14_days_after_remedy_available" : ""
}
```
