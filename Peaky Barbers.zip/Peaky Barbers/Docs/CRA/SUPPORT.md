# Поддержка и окончание срока службы

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "automatic_updates_and_opt_out" : "",
  "end_of_life_migration" : "",
  "expected_useful_life" : "",
  "owner" : "",
  "reference" : "CRA Article 13(8); Annex VII(4)",
  "release_date" : "",
  "rollback_strategy" : "",
  "security_update_channel" : "",
  "supplier_support_constraints" : [

  ],
  "support_end_date" : "",
  "support_period_rationale" : "",
  "update_signature_verification" : "",
  "user_notifications" : ""
}
```
