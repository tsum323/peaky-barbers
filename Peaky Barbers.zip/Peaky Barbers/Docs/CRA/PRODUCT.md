# Досье CRA

Редактируемый черновик: заполните поля, приложите доказательства, получите необходимые проверку и подпись. Ключи JSON и CSV — стабильные идентификаторы обмена. Шаблон не подтверждает соответствие.

[Regulation (EU) 2024/2847](https://eur-lex.europa.eu/eli/reg/2024/2847/oj)

```json
{
  "alternative_security_solutions" : [

  ],
  "approval" : "",
  "architecture_and_data_flows" : [

  ],
  "assessment_route" : "",
  "classification_and_rationale" : "",
  "design_development_production_controls" : [

  ],
  "foreseeable_misuse" : "",
  "hardware_photos_and_markings" : [

  ],
  "intended_use" : "",
  "manufacturer" : {
    "address" : "",
    "contact" : "",
    "name" : ""
  },
  "monitoring_and_validation" : [

  ],
  "partially_applied_clauses" : [

  ],
  "product_id" : "",
  "reference" : "CRA Article 13; Annex VII",
  "retention_end" : "",
  "review_date" : "",
  "scope_and_exclusions_rationale" : "",
  "standards_and_certificates" : [

  ],
  "technical_document_owner" : "",
  "version" : ""
}
```
